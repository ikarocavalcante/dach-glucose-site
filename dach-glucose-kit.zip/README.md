
# DACH Glucose Kit — GitHub Pages Ready

Produzido em 2025-08-13. Pronto para publicar grátis via GitHub Pages.

## Estrutura
- `/de/index.html` — Pre‑lander (alemão), policy‑safe.
- `/de/quiz.html` — Quiz de 3 passos para retenção e pré‑qualificação.
- `/privacy/de.html` e `/privacy/en.html` — Páginas de privacidade.

## Publicar no GitHub Pages (grátis)
1. Crie um repositório público no GitHub (ex.: `dach-glucose-site`).
2. Faça upload dos arquivos desta pasta na raiz do repo.
3. Vá em **Settings → Pages → Source**: selecione **Deploy from a branch** e branch **main**, pasta **/root**.
4. Salve. Seu site sairá como `https://SEUUSUARIO.github.io/dach-glucose-site/`.
5. A página inicial é `.../de/index.html`. O quiz é `.../de/quiz.html`.

## Google Ads — Rascunhos
- Keywords (DE, phrase/exact): "blutzucker senken", "blutzucker natürlich", "blutzucker unterstützung", "glukose kontrolle", "zuckerwerte verbessern"
- Negativas: "kostenlos", "pdf", "arzt", "diagnose", "heilung", "insulin", "metformin", "nebenwirkungen", "studie"
- Títulos: "Sanfte tägliche Unterstützung – Ohne Heilversprechen", "Alltag leichter starten – 1‑Minuten‑Gewohnheit", "Blutzucker im Alltag unterstützen"
- Descrições: "Neutrale Infos + kurze Routine. Ohne Vorher/Nachher. Jetzt ansehen."
- Lances: CPC máx. inicial €0,10–0,25 | Orçamento €5–10/dia | Localizações: Alemanha/Áustria/Schweiz | Idioma: Alemão

## Observações de Compliance
- Não prometa curar/ tratar/ diagnosticar condições. Use "unterstützt", "Wohlbefinden", "alltagstauglich".
- Evite sintomas específicos de doenças. Mantenha linguagem de bem‑estar geral.
